import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
import math

class GoToGoal(Node):
    def __init__(self):
        super().__init__('goto_goal')

        self.pub = self.create_publisher(Twist, 'turtle1/cmd_vel', 10)
        self.sub = self.create_subscription(Pose, 'turtle1/pose', self.pose_callback, 10)

        self.goal_x = 8.0
        self.goal_y = 8.0

        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0

    def pose_callback(self, msg):
        self.x = msg.x
        self.y = msg.y
        self.theta = msg.theta

        cmd = Twist()

        dx = self.goal_x - self.x
        dy = self.goal_y - self.y

        distance = math.sqrt(dx*dx + dy*dy)
        angle_to_goal = math.atan2(dy, dx)

        angle_error = angle_to_goal - self.theta
        angle_error = math.atan2(math.sin(angle_error), math.cos(angle_error))

        # ✅ STOP CONDITION (VERY IMPORTANT)
        if distance < 0.15:
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            self.pub.publish(cmd)
            return

        # 🔥 PHASE 1: ALIGN FIRST (IMPORTANT FIX)
        if abs(angle_error) > 0.2:
            cmd.linear.x = 0.0
            cmd.angular.z = 3.0 * angle_error
        else:
            # 🔥 PHASE 2: MOVE FORWARD AFTER ALIGNMENT
            cmd.linear.x = 1.5 * distance
            cmd.angular.z = 2.0 * angle_error

        self.pub.publish(cmd)

def main():
    rclpy.init()
    node = GoToGoal()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
