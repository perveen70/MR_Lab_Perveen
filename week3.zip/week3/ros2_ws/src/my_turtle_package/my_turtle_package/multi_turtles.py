import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.srv import Spawn

class MultiTurtles(Node):
    def __init__(self):
        super().__init__('multi_turtles')

        self.cli = self.create_client(Spawn, 'spawn')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for spawn service...')

        self.req = Spawn.Request()
        self.req.x = 2.0
        self.req.y = 2.0
        self.req.theta = 0.0
        self.req.name = 'turtle2'

        self.future = self.cli.call_async(self.req)

        self.pub1 = self.create_publisher(Twist, 'turtle1/cmd_vel', 10)
        self.pub2 = self.create_publisher(Twist, 'turtle2/cmd_vel', 10)

        self.timer = self.create_timer(0.2, self.move)

    def move(self):
        msg1 = Twist()
        msg2 = Twist()

        # turtle1 circle
        msg1.linear.x = 2.0
        msg1.angular.z = 1.0

        # turtle2 straight line
        msg2.linear.x = 2.0
        msg2.angular.z = 0.0

        self.pub1.publish(msg1)
        self.pub2.publish(msg2)

def main():
    rclpy.init()
    node = MultiTurtles()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
