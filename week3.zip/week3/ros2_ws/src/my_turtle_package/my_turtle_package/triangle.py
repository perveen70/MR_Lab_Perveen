import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import time

class Triangle(Node):
    def __init__(self):
        super().__init__('triangle_node')
        self.pub = self.create_publisher(Twist, 'turtle1/cmd_vel', 10)
        self.timer = self.create_timer(0.1, self.run)
        self.step = 0
        self.start_time = time.time()

    def run(self):
        msg = Twist()

        duration = time.time() - self.start_time

        # Each side move
        if self.step < 3:
            if duration < 2:
                msg.linear.x = 2.0
            elif duration < 3:
                msg.linear.x = 0.0
                msg.angular.z = 2.0
            else:
                self.step += 1
                self.start_time = time.time()
        else:
            msg.linear.x = 0.0
            msg.angular.z = 0.0

        self.pub.publish(msg)

def main():
    rclpy.init()
    node = Triangle()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
