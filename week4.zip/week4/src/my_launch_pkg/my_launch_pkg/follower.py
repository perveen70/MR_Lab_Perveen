import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
import math

class TurtleFollower(Node):

    def __init__(self):
        super().__init__('turtle_follower')

        self.turtle1_pose = None
        self.turtle2_pose = None

        self.create_subscription(
            Pose,
            '/turtle1/pose',
            self.turtle1_callback,
            10)

        self.create_subscription(
            Pose,
            '/turtle2/pose',
            self.turtle2_callback,
            10)

        self.cmd_pub = self.create_publisher(
            Twist,
            '/turtle2/cmd_vel',
            10)

        self.timer = self.create_timer(
            0.1,
            self.follow_turtle)

    def turtle1_callback(self, msg):
        self.turtle1_pose = msg

    def turtle2_callback(self, msg):
        self.turtle2_pose = msg

    def follow_turtle(self):

        if self.turtle1_pose is None or self.turtle2_pose is None:
            return

        dx = self.turtle1_pose.x - self.turtle2_pose.x
        dy = self.turtle1_pose.y - self.turtle2_pose.y

        distance = math.sqrt(dx**2 + dy**2)

        angle_to_target = math.atan2(dy, dx)

        angle_error = angle_to_target - self.turtle2_pose.theta

        while angle_error > math.pi:
            angle_error -= 2 * math.pi

        while angle_error < -math.pi:
            angle_error += 2 * math.pi

        cmd = Twist()

        if distance > 0.5:
            cmd.linear.x = 2.0 * distance
            cmd.angular.z = 6.0 * angle_error
        else:
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0

        self.cmd_pub.publish(cmd)

def main(args=None):
    rclpy.init(args=args)

    node = TurtleFollower()

    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
