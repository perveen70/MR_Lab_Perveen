import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
import numpy as np

class LidarNavigator(Node):
    def __init__(self):
        super().__init__('lidar_navigator')

        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10)

        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)

        # Thresholds
        self.front_threshold = 0.5
        self.side_threshold = 0.5

    def scan_callback(self, msg):
        ranges = np.array(msg.ranges)

        # ✅ Clean data
        ranges = np.where(np.isinf(ranges), 10, ranges)
        ranges = np.where(np.isnan(ranges), 10, ranges)

        # ✅ Define regions
        front = np.concatenate((ranges[:20], ranges[-20:]))
        left = ranges[60:120]
        right = ranges[-120:-60]

        # ✅ Minimum distance
        front_dist = np.min(front)
        left_dist = np.min(left)
        right_dist = np.min(right)

        twist = Twist()

        # ✅ Obstacle logic
        if front_dist < self.front_threshold:
            twist.linear.x = 0.0

            # Turn toward open side
            if left_dist > right_dist:
                twist.angular.z = 0.5
            else:
                twist.angular.z = -0.5

        else:
            # Move forward
            # Wall following logic
            error = left_dist - 0.5
            twist.linear.x = 0.15
            twist.angular.z = -0.5 * error

def main():
    rclpy.init()
    node = LidarNavigator()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
