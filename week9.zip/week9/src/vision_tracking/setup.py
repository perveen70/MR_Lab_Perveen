from setuptools import setup

package_name = 'vision_tracking'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='perveen',
    maintainer_email='perveen@todo.todo',
    description='Vision tracking package',
    license='TODO',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'camera_follower = vision_tracking.camera_follower:main',
        ],
    },
)
