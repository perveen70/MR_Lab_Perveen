import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image  
from geometry_msgs.msg import Twist  
from cv_bridge import CvBridge     
import cv2                        
import numpy as np                 

class CameraFollower(Node):
    def __init__(self):
        super().__init__('camera_follower')
        
        # Task 1: Camera Subscription
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10)
            
        # Motion Command Publisher
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.bridge = CvBridge()
       
        # --- Strict Demo Parameters ---
        # --- Strict Demo Parameters ---
        self.kp = 0.0012                # UNTOUCHED: Your working alignment gain
        self.center_deadband = 40       # UNTOUCHED: Your working pixel deadband
        self.forward_speed = 0.12       # UNTOUCHED: Your working linear approach speed
        
        # FIXED: Increased to account for OpenCV's 255x intensity multiplier.
        # This forces the robot to get significantly closer to the sphere before stopping.
        self.stop_area_size = 350000000
        self.get_logger().info("Demo Pipeline Armed. Threshold scaled for giant object.")

    def image_callback(self, msg):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8') 
        except Exception as e:
            self.get_logger().error(f'CvBridge Error: {e}')
            return

        # Get horizontal frame layout dimensions
        _, width, _ = cv_image.shape
        image_center_x = width // 2

        # Task 2: Segment Green Colorspace
        hsv_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)
        lower_green = np.array([35, 100, 40])
        upper_green = np.array([85, 255, 255])
        mask = cv2.inRange(hsv_image, lower_green, upper_green)

        # Task 3: Compute Centroid
        moments = cv2.moments(mask)
        twist = Twist()

        # STEP 1: Detection Check
        if moments["m00"] > 800: 
            cx = int(moments["m10"] / moments["m00"])
            cy = int(moments["m01"] / moments["m00"])
            
            # Crosshair telemetry overlays
            cv2.circle(cv_image, (cx, cy), 10, (0, 0, 255), -1)
            cv2.line(cv_image, (image_center_x, 0), (image_center_x, cv_image.shape[0]), (255, 0, 0), 1)

            # Task 4: Calculate Error
            error_x = image_center_x - cx
            
            # STEP 2: Alignment Check (Focus only on turning if out of bounds)
            if abs(error_x) > self.center_deadband:
                twist.linear.x = 0.0
                twist.angular.z = self.kp * error_x
                self.get_logger().info(f"[ALIGNING] Error: {error_x} px | Turning toward target.")
            
            # STEP 3: Centered -> Evaluate Distance
            else:
                # Stops only if it completely surpasses 120 Million pixels
                if moments["m00"] > self.stop_area_size:
                    # Task 5: Arrived closely next to obstacle
                    twist.linear.x = 0.0
                    twist.angular.z = 0.0
                    self.get_logger().info(f"[ARRIVED] Target reached closely. Area: {int(moments['m00'])}")
                else:
                    # Task 5: Move Forward toward target since it is below 120 Million pixels
                    twist.linear.x = self.forward_speed
                    twist.angular.z = self.kp * error_x # Minor adjustments while driving
                    self.get_logger().info(f"[APPROACHING] Centered! Driving forward. Current Area: {int(moments['m00'])}")
                
        # STEP 4: Safety Stop / Search Loop
        else:
            twist.linear.x = 0.0
            twist.angular.z = 0.15 
            self.get_logger().info("[SEARCHING] Target lost. Rotating to scan environment...")

        # Publish commands to wheels
        self.publisher.publish(twist)

        # Show feeds
        cv2.imshow("Tracking View", cv_image)
        cv2.imshow("Green Isolation Mask", mask)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    camera_follower = CameraFollower()
    try:
        rclpy.spin(camera_follower)
    except KeyboardInterrupt:
        pass
    camera_follower.destroy_node()
    rclpy.shutdown()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
